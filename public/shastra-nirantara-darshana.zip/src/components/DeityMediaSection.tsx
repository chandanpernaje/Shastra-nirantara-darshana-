import React, { useState } from 'react';
import { DeityMediaItem } from '../data/articles';
import { ExternalLink, Play, Sparkles } from 'lucide-react';

interface DeityMediaSectionProps {
  mediaItems: DeityMediaItem[];
  isDark: boolean;
}

export const DeityMediaSection: React.FC<DeityMediaSectionProps> = ({
  mediaItems,
  isDark,
}) => {
  const [selectedDeity, setSelectedDeity] = useState<string>('all');

  const filteredItems = selectedDeity === 'all'
    ? mediaItems
    : mediaItems.filter(item => item.deity === selectedDeity);

  return (
    <section id="deity-section" className="mt-14 sm:mt-20 scroll-mt-20">
      {/* Ornate Divider */}
      <div className="ornament-divider mb-8">
        <span className="text-[#c6923b] text-base select-none">✦</span>
      </div>

      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-6 sm:mb-8">
        <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-[#c6923b] uppercase tracking-wider mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>ಉಪಾಸನಾ ದರ್ಶನ</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-bold font-serif text-balance">
          ದೇವತಾ ಚಿತ್ರಗಳು ಹಾಗೂ ಪ್ರವಚನಗಳು
        </h2>
        <p className={`mt-2 text-xs sm:text-sm leading-relaxed ${isDark ? 'text-[#b8a694]' : 'text-[#625143]'}`}>
          ಶ್ರೀ ಮಹಾಗಣಪತಿ, ಪರಮಶಿವ, ಜಗನ್ಮಾತೆ ಲಲಿತಾ ಪರಮೇಶ್ವರಿ ಹಾಗೂ ಶ್ರೀಕೃಷ್ಣ ಪರಮಾತ್ಮನ ಪಾವನ ಸ್ವರೂಪ ಮತ್ತು ಉಪಾಸನಾ ವಿಚಾರಗಳು.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-center gap-1.5 sm:gap-2 flex-wrap mb-8">
        {[
          { id: 'all', label: 'ಎಲ್ಲಾ (೮)' },
          { id: 'ಗಣಪತಿ', label: 'ಶ್ರೀ ಗಣಪತಿ' },
          { id: 'ಶಿವ', label: 'ಪರಮಶಿವ' },
          { id: 'ದೇವಿ', label: 'ಶ್ರೀ ಲಲಿತಾ' },
          { id: 'ಕೃಷ್ಣ', label: 'ಶ್ರೀಕೃಷ್ಣ' },
        ].map((tab) => {
          const isActive = selectedDeity === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSelectedDeity(tab.id)}
              className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all duration-200 cursor-pointer active:scale-95 ${
                isActive
                  ? 'bg-[#c6923b] text-white shadow-sm'
                  : isDark
                  ? 'bg-[#291e18] text-[#c7b7a5] hover:bg-[#342720]'
                  : 'bg-[#f0e7d8] text-[#5c493a] hover:bg-[#e7dcce]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Media Grid: strictly matching original classes and enhanced for responsiveness */}
      <ul className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">
        {filteredItems.map((item) => (
          <li key={item.id} className="h-full">
            <a
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              title={`${item.title} - ಯೂಟ್ಯೂಬ್‌ನಲ್ಲಿ ವೀಕ್ಷಿಸಿ`}
              className={`group flex h-full flex-col overflow-hidden rounded-xl border transition-all duration-200 shadow-sm hover:-translate-y-1 hover:border-[#c6923b] hover:shadow-lg ${
                isDark
                  ? 'border-[#85541e]/30 bg-[#221a15]'
                  : 'border-[#c6923b]/25 bg-white'
              }`}
            >
              {/* Image Container */}
              <div className="relative aspect-square w-full overflow-hidden bg-[#efe5d5]">
                <img
                  src={item.image}
                  alt={item.title}
                  loading="lazy"
                  width={1024}
                  height={1024}
                  className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />

                {/* Deity Tag */}
                <span className="absolute top-2 left-2 rounded bg-black/60 backdrop-blur-xs px-2 py-0.5 text-[10px] font-medium text-amber-200">
                  {item.deityLabel}
                </span>

                {/* Play affordance overlay on hover */}
                <div className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-full bg-red-600/90 text-white shadow-lg transition-transform group-hover:scale-110">
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </div>
                </div>
              </div>

              {/* Title and metadata */}
              <div className="flex flex-1 flex-col justify-between p-3 sm:p-4">
                <div>
                  <h3
                    className={`line-clamp-2 text-sm sm:text-base leading-relaxed font-semibold font-serif transition-colors ${
                      isDark
                        ? 'text-[#f5ebd7] group-hover:text-[#d8a349]'
                        : 'text-[#241a14] group-hover:text-[#9a6f23]'
                    }`}
                  >
                    {item.title}
                  </h3>
                  <p
                    className={`mt-1.5 text-[11px] sm:text-xs line-clamp-2 leading-relaxed ${
                      isDark ? 'text-[#b8a694]' : 'text-[#625143]'
                    }`}
                  >
                    {item.description}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-black/5 dark:border-white/5 flex items-center justify-between text-[11px] text-[#8c6d48]">
                  <span>{item.duration || 'ವಿಡಿಯೋ ಪ್ರವಚನ'}</span>
                  <div className="flex items-center gap-1 text-red-600 dark:text-red-400 font-medium">
                    <span className="hidden xs:inline">ವೀಕ್ಷಿಸಿ</span>
                    <ExternalLink className="w-3 h-3" />
                  </div>
                </div>
              </div>
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
};
